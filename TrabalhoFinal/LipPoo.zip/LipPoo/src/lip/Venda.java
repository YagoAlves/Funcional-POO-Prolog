package lip;

public class Venda {
	
	private String nomeProtudo;
	public String getNomeProtudo() {
		return nomeProtudo;
	}
	public void setNomeProtudo(String nomeProtudo) {
		this.nomeProtudo = nomeProtudo;
	}
	public int getQuantidadeVendida() {
		return QuantidadeVendida;
	}
	public void setQuantidadeVendida(int quantidadeVendida) {
		QuantidadeVendida = quantidadeVendida;
	}
	@Override
	public String toString() {
		return "Venda [nomeProtudo=" + nomeProtudo + ", QuantidadeVendida=" + QuantidadeVendida + ", ValorTotal="
				+ ValorTotal + "]";
	}
	public Venda() {
		super();
	}
	public float getValorTotal() {
		return ValorTotal;
	}
	public void setValorTotal(float valorTotal) {
		ValorTotal = valorTotal;
	}
	private int QuantidadeVendida;
	private float ValorTotal;
	
}
