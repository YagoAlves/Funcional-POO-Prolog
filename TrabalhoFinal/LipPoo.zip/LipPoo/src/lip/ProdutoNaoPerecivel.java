package lip;

public class ProdutoNaoPerecivel extends Produto{

	public ProdutoNaoPerecivel() {
		// TODO Auto-generated constructor stub
	}

}
