package lip;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Loja {
	
	private ArrayList<Produto> Produtos = new ArrayList<>();
	private ArrayList<Venda> Vendas = new ArrayList<>();
	
	void criaProdutoNaoPer () {
		
		Scanner ler = new Scanner(System.in);
		Produto p = new Produto();
		
		System.out.println("Informe o nome");
		p.setNome(ler.next());
		
		System.out.println("Informe o id");
		p.setId(ler.nextInt());
		
		System.out.println("Informe a quantidade em estoque");
		p.setQtdEstoque(ler.nextInt());
		
		System.out.println("Informe o valor do produto");
		p.setValor(ler.nextFloat());
	
		Produtos.add(p);
	}

	void criaProdutoPer () throws ParseException {
	
	Scanner ler = new Scanner(System.in);
	ProdutoPerecivel p = new ProdutoPerecivel();
	
	System.out.println("Informe o nome");
	p.setNome(ler.next());
	
	System.out.println("Informe o id");
	p.setId(ler.nextInt());
	
	System.out.println("Informe a quantidade em estoque");
	p.setQtdEstoque(ler.nextInt());
	
	System.out.println("Informe o valor do produto");
	p.setValor(ler.nextFloat());
	
	System.out.println("Data de validade");
	String data = ler.next();
	DateFormat formatter = new SimpleDateFormat("MM/dd/yy");
	Date date = (Date)formatter.parse(data);
	
	p.setDataVencimento(date);
	
	Produtos.add(p);
	
	}

	void mostraEstoque () {
		for (int i = 0; i < Produtos.size(); i++) {
			System.out.println(Produtos.get(i).toString());
		}		
	}
	
	void debita (String nome, int qtdVendida) {
		for (int i = 0; i < Produtos.size(); i++) {
			if (nome.equals(Produtos.get(i).getNome())) {
				if(Produtos.get(i).getQtdEstoque() >= qtdVendida) {
					Produtos.get(i).setQtdEstoque( Produtos.get(i).getQtdEstoque() - qtdVendida); 
				}
			}
		}
		avisoFimDeEstoque();
	}
	
	void criaVenda() {
		Scanner ler = new Scanner(System.in);
		Venda v = new Venda();
		
		System.out.println("Informe o nome do produto");
		v.setNomeProtudo(ler.next());
		
		System.out.println("Informe a quantidade vendida");
		v.setQuantidadeVendida(ler.nextInt());
		
		System.out.println("Informe o valor total");
		v.setValorTotal(ler.nextFloat());
		debita(v.getNomeProtudo(), v.getQuantidadeVendida());
		Vendas.add(v);
	}
	
	void valorEmCaixa () {
		float soma = 0;
		for (int i = 0; i < Vendas.size(); i++) {
			soma += Vendas.get(i).getValorTotal();
		} 
		System.out.println("Valor em caixa R$ " + soma);
	}
	
	void avisoFimDeEstoque() {
		int i;
		for (i = 0; i < Produtos.size(); i++) {
			if (Produtos.get(i).getQtdEstoque() == 0) {
				System.out.println("Produtos em falta \n "
						+ Produtos.get(i).toString());
			}
		}
	}
	void menu () throws ParseException {
		Loja l = new Loja();
		Produto p = new Produto();
		Venda v = new Venda();
		
		int op = 0;
		Scanner ler = new Scanner(System.in);
		
		while (op != 5) {
			
			System.out.println(" 1 - Cadastrar vendas  \n 2 - Cadastrar produtos\n 3 - Consultar estoque \n 4 - Consultar caixa   \n 5 - Sair   \n");
			op = ler.nextInt();
			
			switch (op) {
			case 1:
				criaVenda();
				break;	
			case 2:
				int aux;
				System.out.println("1 - Produto perecivel \n"
						+ "2 - Produto não perecivel");
				aux = ler.nextInt();
				
				if (aux == 1) {
					criaProdutoPer();
				} else
				
				if (aux == 2) {
					criaProdutoNaoPer();
				} else {
					System.out.println("Opção invalida");
				}
				break;
			case 3:
				mostraEstoque();
				break;
			case 4:
				valorEmCaixa();
			case 5:
				break;
			default:
				System.out.println("Opção invalida");	
			}
		}
	}
	
	public ArrayList<Produto> getProdutos() {
		return Produtos;
	}
	public void setProdutos(ArrayList<Produto> produtos) {
		Produtos = produtos;
	}
	public ArrayList<Venda> getVendas() {
		return Vendas;
	}
	public void setVendas(ArrayList<Venda> vendas) {
		Vendas = vendas;
	}

}
