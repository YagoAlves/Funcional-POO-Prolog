package lip;

import java.text.ParseException;

public class Controle {

	public static void main(String[] args) throws ParseException {
		Loja l = new Loja();	
		l.menu();
	}
}
