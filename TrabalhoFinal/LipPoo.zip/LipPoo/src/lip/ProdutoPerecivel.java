package lip;

import java.util.Date;

public class ProdutoPerecivel extends Produto {
	
	
	
	public ProdutoPerecivel() {
		super();
	}

	private Date dataVencimento;

	public Date getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(Date dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
}
