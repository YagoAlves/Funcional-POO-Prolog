package lip;

public class Produto {

	@Override
	public String toString() {
		return "Produto [nome=" + nome + ", valor=" + valor + ", qtdEstoque=" + qtdEstoque + ", id=" + id
				+ "]";
	}

	public Produto() {
		
	}

	private String nome;
	private float valor;
	private int qtdEstoque;
	private int id;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	public int getQtdEstoque() {
		return qtdEstoque;
	}
	public void setQtdEstoque(int qtdEstoque) {
		this.qtdEstoque = qtdEstoque;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
